# Security Policy

To report a security vulnerability, please use the [Tidelift security contact](https://discord.gg/5wSZfq9eBf). Tidelift will coordinate the fix and disclosure.
